// Morgan Hand 01/16/24 
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Slow down you crazy child");

	}

}

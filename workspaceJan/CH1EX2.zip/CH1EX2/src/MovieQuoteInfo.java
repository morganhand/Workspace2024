//Morgan Hand 11/16/24
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("On Wednesdays we wear pink");
		System.out.println("Karen Smith");
		System.out.println("Mean Girls");
		System.out.println("2004");
	}

}

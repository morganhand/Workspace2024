// Morgan Hand 01/15/24
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from CSC 151");

	}

}
